/**
 * Created by itolfo2 on 2015/12/9.
 */

var dbg = new DJI.Debugger();
var generalIo = new DJI.ServiceGeneral();
var dbgout;

function open_debugger(f)
{
    dbg.connect(f);
}

generalIo.addListener('device_arrival', function (msg) {
    if ('PRODUCT_TYPE' in msg)
        if (msg.PRODUCT_TYPE == 'Controller')
            open_debugger(msg.FILE);
});
generalIo.connect();



window.onload = function(){
    dbgout = document.getElementById('dbgout');
};

function log_to_console(s){
    var c = document.getElementById('conout');

    c.innerHTML += s + '\n';
    c.scrollTop = c.scrollHeight;
}

function debug()
{
    var r = parseInt(document.getElementById('receiver').value);
    var ri = parseInt(document.getElementById('receiver_index').value);
    var cs = parseInt(document.getElementById('cmd_set').value);
    var ci = parseInt(document.getElementById('cmd_id').value);
    var cd = document.getElementById('cmd_data').value;

    dbg.send(r, ri, cs, ci, cd, function(m){
        console.log(m);
        log_to_console(JSON.stringify(m));
    });
}

function clearAll()
{
    var c = document.getElementById('conout');
    c.innerHTML = "";
}