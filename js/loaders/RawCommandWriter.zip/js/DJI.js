/**
 * Created by itolfo2 on 2015/10/26.
 */
function is_function(obj) {
    return typeof obj == "function";
}


// general   : "ws://localhost:19870/general"
// config    : "ws://localhost:19870/controller/config/user/XXXXXXXXX"
// upgrade   : "ws://localhost:19870/controller/upgrade/XXXXXXXXX"
// navigation: "ws://localhost:19870/controller/navigation/XXXXXXXXX"
// simulator : "ws://localhost:19870/controller/simulator/XXXXXXXXX"

var DJI = {REVISION: '1'};

DJI.ServiceUrls = {
    general: 'ws://localhost:19870/general',
    config: 'ws://localhost:19870/controller/config/user/',
    upgrade: 'ws://localhost:19870/controller/upgrade/',
    navigation: 'ws://localhost:19870/controller/navigation/',
    simulator: 'ws://localhost:19870/controller/simulator/'
};

DJI.ServiceIo = function () {
    this.cur_ws = null;
    this.cur_status = "service_failure";
    this.cmd_history_ = {}; // internal map, trace all command that send by Write().
};

// cmd object must have a callback function [on_reply] object
// if no this function object, just log to console
DJI.ServiceIo.prototype.send = function (cmd) {
    var seq = Math.random().toString(36).substring(7); // generate random seq string
    cmd.SEQ = seq; // insert command with seq
    this.cmd_history_[seq] = cmd; // save the send command

    var txt = JSON.stringify(cmd);
    if (this.cur_ws instanceof WebSocket) {
        this.cur_ws.send(txt);
    }
};

// general as default
DJI.ServiceIo.prototype.connect = function (ws_url, on_ws_message, auto_retry, on_ws_failure, on_ws_success) {
    if (ws_url == null)
        ws_url = "ws://localhost:19870/general";
    if (auto_retry == null)
        auto_retry = true;
    var self_ = this;
    var do_connect = function () {
        var service_websocket = new WebSocket(ws_url);

        service_websocket.onopen = function () {
            console.log("[" + ws_url + "] service connect ok!");
            self_.cur_ws = this;
            self_.cur_status = "link_ok";
            if (is_function(on_ws_success))
                on_ws_success();
        };
        service_websocket.onclose = function () {
            self_.cur_ws = null;
            console.log("[" + ws_url + "] service closed!");
            self_.cur_status = "service_failure";
            if (auto_retry)
                do_connect(); // just retry
            if (is_function(on_ws_failure))
                on_ws_failure(); // notify no this type of service!
        };
        service_websocket.onerror = function () {
            self_.cur_ws = null;
            console.log("[" + ws_url + "] service error!");
        };
        service_websocket.onmessage = function (e) {
            var msg = JSON.parse(e.data);
            if ("SEQ" in msg) { // text with seq
                if (msg.SEQ in self_.cmd_history_) { // seq is send by self.Write
                    var cmd = self_.cmd_history_[msg.SEQ];
                    if (is_function(cmd.on_reply)) { // try to call command on_reply
                        cmd.on_reply(msg);
                    }
                    else
                        console.log(msg);
                    delete self_.cmd_history_[msg.SEQ]; // remove from trace object
                    return; // ack msg already handled
                }
            }

            if (is_function(on_ws_message)) on_ws_message(e);
        };
    };
    do_connect();
};

function getV(key_, obj_) {
    if (key_ in obj_)
        return obj_[key_];
    return '';
}

DJI.ServiceGeneral = function () {
    var self_ = this;
    this.serviceIoGeneral = new DJI.ServiceIo();

    var device_list_ = {};
    var app_status_;
    var app_version_;
    var app_hash_;
    var debug_status_;
    var listener_ = {};

    var handleAppStatus = function (msg) {
        if ('APP_STATUS' in msg) app_status_ = msg.APP_STATUS;
    };

    var handles_ = {
        'app_ver_notify': function () {
            app_status_ = getV('APP_STATUS', arguments[0]);
            console.log("App status  :", app_status_);
        },
        'app_ver': function () {
            app_version_ = getV('APP_VERSION', arguments[0]);
            app_hash_ = getV('HASH_SERVICE', arguments[0]);
            console.log("App version :", app_version_, app_hash_);
        },
        'debug_status': function () {
            debug_status_ = getV('DEBUGGER_ENABLED', arguments[0]);
            console.log("Debugger    :", debug_status_);
        },
        'device_arrival': function (m) {
            device_list_[m['FILE']] = m;
            console.log(m);
        }
    };

    var messageGeneralHandler = function (msg) {
        if ('EVENT' in msg) {
            if (msg.EVENT in handles_)
                handles_[msg.EVENT](msg);
            if (msg.EVENT in listener_) {
                var arr = listener_[msg.EVENT];
                if (arr instanceof Array) {
                    for (var i = 0; i < arr.length; i++)
                        if (is_function(arr[i]))
                            arr[i](msg);
                }
            }
        }
    };

    this.addListener = function (e, handler) {
        var arr;
        if (e in listener_) {
            arr = listener_[e];
            if (arr instanceof Array) {
            }
            else
                arr = new Array;
            arr.push(handler);
        }
        else {
            arr = new Array;
            arr.push(handler);
        }
        listener_[e] = arr;
    };

    this.clearListener = function (e) {
        if (e == null)
            listener_ = {};
        else if (e in listener_)
            delete listener_[e];
    };

    this.getConnectedDeviceInfo = function () {
        return device_list_;
    };

    this.getVersion = function () {
        return app_version_;
    };

    this.getAppStatus = function () {
        return app_status_;
    };

    this.getMessageHandle = function () {
        return messageGeneralHandler;
    }
};

DJI.ServiceGeneral.prototype.onMessage = function (e, on_device_event) {
    var msg = JSON.parse(e.data);

    if (is_function(on_device_event))
        on_device_event(msg);
};

DJI.ServiceGeneral.prototype.connect = function (on_device_event) {
    var self_ = this;
    if (on_device_event == null)
        on_device_event = this.getMessageHandle();
    this.serviceIoGeneral.connect("ws://localhost:19870/general", function (e) {
        self_.onMessage(e, on_device_event);
    });
};

DJI.Debugger = function () {
    this.serviceIo = new DJI.ServiceIo();
    this.fileHash = '';
};

DJI.Debugger.prototype.connect = function (fileHash) {
    this.fileHash = fileHash;
    this.serviceIo.connect(DJI.ServiceUrls.config + fileHash, function (e) {
        var msg = JSON.parse(e.data);
        console.log(msg);
    });
};

DJI.Debugger.prototype.send = function (receiver, receiverIndex, cmdSet, cmdId, cmdData, reply) {
    if (!is_function(reply))
        reply = function (m) {
            console.log(m);
        };
    var d = {
        CMD: 'debug',
        CMD_SET: cmdSet,
        CMD_ID: cmdId,
        CMD_RECEIVER: receiver,
        CMD_RECEIVER_INDEX: receiverIndex,
        CMD_SENDER_INDEX: 0,
        CMD_DATA: cmdData,
        on_reply: reply
    };
    this.serviceIo.send(d);
};
